<?php


namespace Nextend\SmartSlider3\Slider\Base;


class PlatformSliderBase {

    public function addCMSFunctions($text) {

        return $text;
    }
}