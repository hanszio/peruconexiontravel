<?php


namespace Nextend\SmartSlider3Pro\Generator\WordPress;


use Nextend\SmartSlider3\Generator\AbstractGeneratorLoader;

class GeneratorWordPressLoader extends AbstractGeneratorLoader {

}