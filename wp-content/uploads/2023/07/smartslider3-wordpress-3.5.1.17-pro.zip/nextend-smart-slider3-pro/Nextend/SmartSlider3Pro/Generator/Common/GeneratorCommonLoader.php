<?php


namespace Nextend\SmartSlider3Pro\Generator\Common;


use Nextend\SmartSlider3\Generator\AbstractGeneratorLoader;

class GeneratorCommonLoader extends AbstractGeneratorLoader {

}